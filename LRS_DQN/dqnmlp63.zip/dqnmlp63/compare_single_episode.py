import torch
import torch.nn as nn
import torch.optim as optim
import math, random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader

# 기존 파일들에서 필요한 모듈 import
from mlp import MLP
from dataset import ProjectedMNIST
from schedulers import apply_lr_action
from meta_agent import DQNAgent
# (train_utils.py는 여기서는 직접 미니배치 loop를 구현함)

# ---------------------------
# Seed, device, global settings
# ---------------------------
seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)
    
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
state_dim = 6   # [w_mean, w_std, b_mean, b_std, prev_lr, train_loss]
action_dim = 5  # DQN action: 0,1,2,3,4

# ---------------------------
# Helper function: weight statistics (from main.py)
# ---------------------------
def get_weight_statistics(model):
    with torch.no_grad():
        w = model.fc2.weight.view(-1).cpu().numpy()
        b = model.fc2.bias.view(-1).cpu().numpy()
        w_mean = np.mean(w)
        w_std  = np.std(w)
        b_mean = np.mean(b)
        b_std  = np.std(b)
    return np.array([w_mean, w_std, b_mean, b_std], dtype=np.float32)

# ---------------------------
# Experiment function for one method
# ---------------------------
def run_experiment(method_name, scheduler_type=None, num_epochs=10):
    print(f"Starting experiment for {method_name}")
    # 모델, 옵티마이저, GradScaler 초기화
    model = MLP().to(device)
    initial_lr = 0.01
    optimizer = optim.Adam(model.parameters(), lr=initial_lr)
    scaler = torch.amp.GradScaler()
    
    # scheduler 초기화 (DQN은 별도 처리)
    scheduler = None
    if method_name == "DQN":
        # 저장된 DQN 모델 로드하여 스케줄러 역할로 사용
        dqn_agent = DQNAgent(state_dim, action_dim, device)
        dqn_agent.q_network.load_state_dict(torch.load("dqn_model.pth", map_location=device))
        dqn_agent.q_network.eval()  # 학습 없이 평가 모드로 사용
        # state 초기화 함수 (main.py의 init_state 복사)
        def init_state(model, lr, train_loss=1.0):
            weight_stats = get_weight_statistics(model)
            return np.concatenate((weight_stats, np.array([lr, train_loss], dtype=np.float32)))
        current_lr = optimizer.param_groups[0]['lr']
        state = init_state(model, current_lr, 1.0)
    elif scheduler_type == "StepLR":
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.97)
    elif scheduler_type == "ExponentialLR":
        scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.97)
    elif scheduler_type == "CosineAnnealingLR":
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs, eta_min=initial_lr * 0.1)
    elif scheduler_type == "CyclicLR":
        # CyclicLR는 미니배치 단위로 update됨
        scheduler = torch.optim.lr_scheduler.CyclicLR(optimizer, base_lr=initial_lr/10, max_lr=initial_lr, 
                                                      step_size_up=200, mode='triangular2')
    
    # DataLoader 준비 (ProjectedMNIST는 train=True일 때 projector를 fit하므로 사용)
    train_dataset = ProjectedMNIST(train=True)
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4)
    
    criterion = nn.CrossEntropyLoss()
    
    # 미니배치 step 단위 metric 기록
    step_indices = []
    losses = []
    accuracies = []
    lrs = []
    global_step = 0
    
    # 각 epoch마다 미니배치 단위 training loop
    for epoch in range(num_epochs):
        # DQN 방식은 에포크 시작 시, 현재 state로부터 action 선택 후 learning rate 업데이트
        if method_name == "DQN":
            action = dqn_agent.select_action(state)
            apply_lr_action(optimizer, action, initial_lr)
        # 각 epoch의 mini-batch loop
        for batch_idx, (data, target) in enumerate(train_loader):
            model.train()
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            with torch.amp.autocast(device_type="cuda" if torch.cuda.is_available() else "cpu"):
                output = model(data)
                loss = criterion(output, target)
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            
            # mini-batch accuracy 계산
            preds = output.argmax(dim=1)
            correct = preds.eq(target).sum().item()
            accuracy = correct / data.size(0)
            
            # 현재 step의 metric 저장
            step_indices.append(global_step)
            losses.append(loss.item())
            accuracies.append(accuracy)
            lrs.append(optimizer.param_groups[0]['lr'])
            global_step += 1
            
            # CyclicLR는 미니배치마다 scheduler.step() 호출
            if scheduler_type == "CyclicLR":
                scheduler.step()
                
        # 에포크 끝나면, non-CyclicLR의 경우 scheduler.step() (에포크 단위 업데이트)
        if scheduler is not None and scheduler_type != "CyclicLR":
            scheduler.step()
            
        # DQN 방식은 에포크 끝난 후 state 업데이트 (reward 계산 등, 여기서는 업데이트만 기록하고 dqn agent update는 생략)
        if method_name == "DQN":
            # 지난 epoch의 평균 loss (현재 epoch의 미니배치 개수만큼 사용)
            epoch_loss = np.mean(losses[-len(train_loader):])
            new_lr = optimizer.param_groups[0]['lr']
            new_state = init_state(model, new_lr, epoch_loss)
            prev_train_loss = state[-1]
            if epoch_loss > 0 and prev_train_loss > 0:
                log_diff = math.log(epoch_loss) - math.log(prev_train_loss)
            else:
                log_diff = 0.0
            reward = - log_diff * 100
            # 여기서는 dqn_agent 업데이트 없이, 저장된 모델의 성능 평가만 진행
            state = new_state
        print(f"{method_name} - Epoch {epoch+1}/{num_epochs} completed.")
        
    return {
        "steps": step_indices,
        "losses": losses,
        "accuracies": accuracies,
        "lrs": lrs
    }

# ---------------------------
# 각 방법별 실험 실행
# ---------------------------
# 비교할 5가지 방법: key는 방법 이름, value는 내부 scheduler type (DQN은 None)
methods = {
    "DQN": None,
    "StepLR": "StepLR",
    "ExponentialLR": "ExponentialLR",
    "CosineAnnealingLR": "CosineAnnealingLR",
    "CyclicLR": "CyclicLR"
}

results = {}
for method, sched in methods.items():
    results[method] = run_experiment(method, scheduler_type=sched, num_epochs=10)

# ---------------------------
# Plotting: 이동평균(window=10) 적용하여 loss, accuracy, lr 비교
# ---------------------------
window = 10

# (1) Loss 비교: 5개 서브플롯을 하나의 PNG 파일에 저장
fig_loss, axes_loss = plt.subplots(5, 1, figsize=(10, 25))
for i, method in enumerate(methods.keys()):
    steps = results[method]["steps"]
    loss_values = results[method]["losses"]
    loss_ma = pd.Series(loss_values).rolling(window=window).mean()
    axes_loss[i].plot(steps, loss_ma, label=f"{method}")
    axes_loss[i].set_title(f"{method} Loss (Moving Average)")
    axes_loss[i].set_xlabel("Step")
    axes_loss[i].set_ylabel("Loss")
    axes_loss[i].legend()
fig_loss.tight_layout()
fig_loss.savefig("loss_comparison.png")
plt.close(fig_loss)

# (2) Accuracy 비교: 5개 서브플롯을 하나의 PNG 파일에 저장
fig_acc, axes_acc = plt.subplots(5, 1, figsize=(10, 25))
for i, method in enumerate(methods.keys()):
    steps = results[method]["steps"]
    acc_values = results[method]["accuracies"]
    acc_ma = pd.Series(acc_values).rolling(window=window).mean()
    axes_acc[i].plot(steps, acc_ma, label=f"{method}")
    axes_acc[i].set_title(f"{method} Accuracy (Moving Average)")
    axes_acc[i].set_xlabel("Step")
    axes_acc[i].set_ylabel("Accuracy")
    axes_acc[i].legend()
fig_acc.tight_layout()
fig_acc.savefig("accuracy_comparison.png")
plt.close(fig_acc)

# (3) Learning Rate 비교: 5개 방법의 lr 곡선을 하나의 플롯에 그리기
plt.figure(figsize=(10, 6))
for method in methods.keys():
    plt.plot(results[method]["steps"], results[method]["lrs"], label=method)
plt.xlabel("Step")
plt.ylabel("Learning Rate")
plt.title("Learning Rate Comparison")
plt.legend()
plt.savefig("lr_comparison.png")
plt.close()

print("All experiments completed and plots saved.")