# main.py
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
import random
import math
import matplotlib.pyplot as plt
import csv
import os

from mlp import MLP
from dataset import ProjectedMNIST
from schedulers import apply_lr_action  # Modified LR action function
from meta_agent import DQNAgent
import train_utils

#############################################
# 가중치 통계 함수 (논문 state 방식)
#############################################
def get_weight_statistics(model):
    with torch.no_grad():
        w = model.fc2.weight.view(-1).cpu().numpy()
        b = model.fc2.bias.view(-1).cpu().numpy()
        w_mean = np.mean(w)
        w_std  = np.std(w)
        b_mean = np.mean(b)
        b_std  = np.std(b)
    return np.array([w_mean, w_std, b_mean, b_std], dtype=np.float32)

#############################################
# Seed & device
#############################################
seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#############################################
# Dataset
#############################################
train_dataset = ProjectedMNIST(train=True)
projector = train_dataset.projector
mean = train_dataset.mean
std = train_dataset.std

test_dataset = ProjectedMNIST(train=False, projector=projector, mean=mean, std=std)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False, num_workers=4)

#############################################
# Model, optimizer, scaler
#############################################
model = MLP().to(device)
initial_lr = 0.01
optimizer = optim.Adam(model.parameters(), lr=initial_lr)
scaler = torch.amp.GradScaler()

#############################################
# Training settings
#############################################
num_episodes = 1000  # 전체 에피소드 수
epochs_per_episode = 10  # 한 에피소드 = 10 epoch

#############################################
# DQN Agent
# State: [w_mean, w_std, b_mean, b_std, prev_lr, train_loss] (6차원)
#############################################
state_dim = 6
action_dim = 5
dqn_agent = DQNAgent(state_dim, action_dim, device)

#############################################
# 초기 state 설정
#############################################
def init_state(model, lr, train_loss=1.0):
    weight_stats = get_weight_statistics(model)
    return np.concatenate((weight_stats, np.array([lr, train_loss], dtype=np.float32)))

# 초기 state
current_lr = optimizer.param_groups[0]['lr']
state = init_state(model, current_lr, 1.0)

#############################################
# Metrics dict
#############################################
metrics = {
    "epoch_index": [],   # 전체 진행된 epoch(전역)
    "episode": [],       # 에피소드 index
    "epoch_in_episode": [],  # 에피소드 내 epoch index
    "loss": [],
    "accuracy": [],
    "reward": [],
    "action": [],
    "lr": []
}

global_epoch_count = 0  # 전역 epoch 카운트

#############################################
# Main loop
#############################################
for episode in range(num_episodes):
    print(f"Episode {episode+1}/{num_episodes}")

    for e in range(epochs_per_episode):
        # 1) DQN action selection
        action = dqn_agent.select_action(state)

        # 2) Apply LR modification
        apply_lr_action(optimizer, action, initial_lr)

        # 3) Train for 1 epoch
        train_loss = train_utils.train_one_epoch(model, optimizer, train_loader, device, scaler)

        # 4) Evaluate
        test_loss, test_accuracy = train_utils.evaluate(model, test_loader, device)

        # 5) Compute reward
        #    Daniel et al. 식: 여기서는 이전 train_loss와 새 train_loss 비교 (간단 예시)
        #    (원래는 epoch별 loss log-diff 등 다양하게 가능)
        #    여기서는 state[-1]에 있던 "이전 avg train_loss"와 이번 train_loss 사용
        prev_train_loss = state[-1]
        if train_loss > 0 and prev_train_loss > 0:
            log_diff = math.log(train_loss) - math.log(prev_train_loss)
        else:
            log_diff = 0.0
        reward = - log_diff * 100  # 스케일링

        # 6) Next state
        current_lr = optimizer.param_groups[0]['lr']
        new_state = init_state(model, current_lr, train_loss)

        # 7) DQN update
        done = 0  # 마지막 에피소드의 마지막 epoch이면 done=1
        if (episode == num_episodes - 1) and (e == epochs_per_episode - 1):
            done = 1
        dqn_agent.push(state, action, reward, new_state, done)
        dqn_agent.update()
        dqn_agent.update_target()

        # 8) Record metrics (매 epoch마다 기록)
        metrics["epoch_index"].append(global_epoch_count)
        metrics["episode"].append(episode)
        metrics["epoch_in_episode"].append(e)
        metrics["loss"].append(test_loss)
        metrics["accuracy"].append(test_accuracy)
        metrics["reward"].append(reward)
        metrics["action"].append(action)
        metrics["lr"].append(current_lr)

        print(f"Episode {episode}, Epoch {e}, GlobalEpoch {global_epoch_count}, Test Loss: {test_loss:.4f}, "
              f"Test Accuracy: {test_accuracy*100:.2f}%, Train Loss: {train_loss:.4f}, "
              f"Reward: {reward:.4f}, Action: {action}, LR: {current_lr:.6f}")

        state = new_state
        global_epoch_count += 1

#############################################
# Save metrics to CSV (매 epoch 기록)
#############################################
with open("metrics.csv", "w", newline="") as csvfile:
    fieldnames = ["epoch_index", "episode", "epoch_in_episode", "loss", "accuracy", "reward", "action", "lr"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(len(metrics["epoch_index"])):
        writer.writerow({
            "epoch_index": metrics["epoch_index"][i],
            "episode": metrics["episode"][i],
            "epoch_in_episode": metrics["epoch_in_episode"][i],
            "loss": metrics["loss"][i],
            "accuracy": metrics["accuracy"][i],
            "reward": metrics["reward"][i],
            "action": metrics["action"][i],
            "lr": metrics["lr"][i]
        })

#############################################
# Save trained DQN model
#############################################
torch.save(dqn_agent.q_network.state_dict(), "dqn_model.pth")

#############################################
# Plotting
#############################################
plt.figure(figsize=(12, 10))

plt.subplot(2,2,1)
plt.plot(metrics["epoch_index"], metrics["loss"])
plt.xlabel("Global Epoch")
plt.ylabel("Test Loss")
plt.title("Test Loss per Global Epoch")

plt.subplot(2,2,2)
plt.plot(metrics["epoch_index"], [acc * 100 for acc in metrics["accuracy"]])
plt.xlabel("Global Epoch")
plt.ylabel("Test Accuracy (%)")
plt.title("Test Accuracy per Global Epoch")

plt.subplot(2,2,3)
plt.plot(metrics["epoch_index"], metrics["reward"])
plt.xlabel("Global Epoch")
plt.ylabel("Reward")
plt.title("Reward per Global Epoch")

plt.subplot(2,2,4)
plt.plot(metrics["epoch_index"], metrics["lr"])
plt.xlabel("Global Epoch")
plt.ylabel("Learning Rate")
plt.title("Learning Rate per Global Epoch")

plt.tight_layout()
plt.savefig("training_metrics.png")
plt.show()