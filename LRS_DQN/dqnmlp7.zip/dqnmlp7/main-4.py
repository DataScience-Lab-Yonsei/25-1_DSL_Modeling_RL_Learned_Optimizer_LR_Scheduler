# main.py
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
import random
import math
import matplotlib.pyplot as plt
import csv
import os

from mlp import MLP
from dataset import ProjectedMNIST
from schedulers import apply_lr_action  # Modified LR action function
from meta_agent import DQNAgent
import train_utils

#############################################
# 가중치 통계 함수 (논문 state 방식)
#############################################
def get_weight_statistics(model):
    with torch.no_grad():
        w = model.fc2.weight.view(-1).cpu().numpy()
        b = model.fc2.bias.view(-1).cpu().numpy()
        w_mean = np.mean(w)
        w_std  = np.std(w)
        b_mean = np.mean(b)
        b_std  = np.std(b)
    return np.array([w_mean, w_std, b_mean, b_std], dtype=np.float32)

#############################################
# Seed & device
#############################################
seed = 42
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed(seed)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#############################################
# Dataset
#############################################
train_dataset = ProjectedMNIST(train=True)
projector = train_dataset.projector
mean = train_dataset.mean
std = train_dataset.std

test_dataset = ProjectedMNIST(train=False, projector=projector, mean=mean, std=std)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False, num_workers=4)

#############################################
# Model, optimizer, scaler
#############################################
model = MLP().to(device)
initial_lr = 0.01
optimizer = optim.Adam(model.parameters(), lr=initial_lr)
scaler = torch.amp.GradScaler()

#############################################
# Training settings
#############################################
num_episodes = 100       # 전체 에피소드 수
epochs_per_episode = 10   # 한 에피소드 당 epoch 수

#############################################
# DQN Agent
# State: [w_mean, w_std, b_mean, b_std, prev_lr, train_loss] (6차원)
#############################################
state_dim = 6
action_dim = 5
dqn_agent = DQNAgent(state_dim, action_dim, device)

#############################################
# 초기 state 설정
#############################################
def init_state(model, lr, train_loss=1.0):
    weight_stats = get_weight_statistics(model)
    return np.concatenate((weight_stats, np.array([lr, train_loss], dtype=np.float32)))

current_lr = optimizer.param_groups[0]['lr']
state = init_state(model, current_lr, 1.0)

#############################################
# Metrics dict (에폭 단위 기록)
#############################################
metrics = {
    "epoch_index": [],   # 전역 에폭 index
    "episode": [],
    "epoch_in_episode": [],  # 에피소드 내 epoch index
    "loss": [],
    "accuracy": [],
    "reward": [],
    "action": [],
    "lr": []
}

global_epoch_count = 0

#############################################
# Criterion for mini-batch training (unchanged)
#############################################
criterion = torch.nn.CrossEntropyLoss()

#############################################
# Main loop: 에폭당 액션 한 번 + 미니배치마다 DQN 업데이트, 메트릭 기록은 에폭 단위로
#############################################
for episode in range(num_episodes):
    for epoch in range(epochs_per_episode):
        # --- 에폭 시작 시 한 번만 액션 선택 및 LR 업데이트 ---
        action = dqn_agent.select_action(state)
        apply_lr_action(optimizer, action, initial_lr)
        # ------------------------------------------------------

        # 에폭 내 미니배치 루프: 미니배치마다 학습 및 DQN 업데이트 수행
        epoch_test_loss_sum = 0.0
        epoch_test_accuracy_sum = 0.0
        epoch_reward_sum = 0.0
        num_batches = 0

        for batch_idx, (data, target) in enumerate(train_loader):
            model.train()
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()

            with torch.amp.autocast(device_type="cuda" if torch.cuda.is_available() else "cpu"):
                output = model(data)
                loss = criterion(output, target)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            mini_batch_loss = loss.item()

            # 매 미니배치마다 Test set 평가
            test_loss, test_accuracy = train_utils.evaluate(model, test_loader, device)

            # 보상 계산 (이전 미니배치 손실과 비교)
            prev_loss = state[-1]
            if mini_batch_loss > 0 and prev_loss > 0:
                log_diff = math.log(mini_batch_loss) - math.log(prev_loss)
            else:
                log_diff = 0.0
            reward = - log_diff * 100  # 스케일링

            # 상태 업데이트
            current_lr = optimizer.param_groups[0]['lr']
            new_state = init_state(model, current_lr, mini_batch_loss)

            # 마지막 미니배치인 경우 done=1 (전체 마지막 에폭의 마지막 배치)
            done = 0
            if (episode == num_episodes - 1) and (epoch == epochs_per_episode - 1) and (batch_idx == len(train_loader) - 1):
                done = 1

            # DQN transition 저장 및 업데이트 (액션은 에폭 시작 시 선택한 값 사용)
            dqn_agent.push(state, action, reward, new_state, done)
            dqn_agent.update()
            dqn_agent.update_target()

            state = new_state

            # 누적
            epoch_test_loss_sum += test_loss
            epoch_test_accuracy_sum += test_accuracy
            epoch_reward_sum += reward
            num_batches += 1

        # --- 에폭이 끝난 후 에폭 단위 요약 기록 및 출력 ---
        avg_test_loss = epoch_test_loss_sum / num_batches
        avg_test_accuracy = epoch_test_accuracy_sum / num_batches
        avg_reward = epoch_reward_sum / num_batches

        metrics["epoch_index"].append(global_epoch_count)
        metrics["episode"].append(episode)
        metrics["epoch_in_episode"].append(epoch)
        metrics["loss"].append(avg_test_loss)
        metrics["accuracy"].append(avg_test_accuracy)
        metrics["reward"].append(avg_reward)
        metrics["action"].append(action)
        metrics["lr"].append(current_lr)

        print(f"Episode {episode}, Epoch {epoch}: Avg Test Loss: {avg_test_loss:.4f}, "
              f"Avg Test Accuracy: {avg_test_accuracy*100:.2f}%, Avg Reward: {avg_reward:.4f}, Action: {action}, LR: {current_lr:.6f}")

        global_epoch_count += 1

#############################################
# Save metrics to CSV (에폭 단위 기록)
#############################################
with open("metrics.csv", "w", newline="") as csvfile:
    fieldnames = ["epoch_index", "episode", "epoch_in_episode", "loss", "accuracy", "reward", "action", "lr"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for i in range(len(metrics["epoch_index"])):
        writer.writerow({
            "epoch_index": metrics["epoch_index"][i],
            "episode": metrics["episode"][i],
            "epoch_in_episode": metrics["epoch_in_episode"][i],
            "loss": metrics["loss"][i],
            "accuracy": metrics["accuracy"][i],
            "reward": metrics["reward"][i],
            "action": metrics["action"][i],
            "lr": metrics["lr"][i]
        })

#############################################
# Save trained DQN model
#############################################
torch.save(dqn_agent.q_network.state_dict(), "dqn_model.pth")

#############################################
# Plotting
#############################################
plt.figure(figsize=(12, 10))

plt.subplot(2,2,1)
plt.plot(metrics["epoch_index"], metrics["loss"])
plt.xlabel("Global Epoch")
plt.ylabel("Test Loss")
plt.title("Test Loss per Global Epoch")

plt.subplot(2,2,2)
plt.plot(metrics["epoch_index"], [acc * 100 for acc in metrics["accuracy"]])
plt.xlabel("Global Epoch")
plt.ylabel("Test Accuracy (%)")
plt.title("Test Accuracy per Global Epoch")

plt.subplot(2,2,3)
plt.plot(metrics["epoch_index"], metrics["reward"])
plt.xlabel("Global Epoch")
plt.ylabel("Reward")
plt.title("Reward per Global Epoch")

plt.subplot(2,2,4)
plt.plot(metrics["epoch_index"], metrics["lr"])
plt.xlabel("Global Epoch")
plt.ylabel("Learning Rate")
plt.title("Learning Rate per Global Epoch")

plt.tight_layout()
plt.savefig("training_metrics.png")
plt.show()