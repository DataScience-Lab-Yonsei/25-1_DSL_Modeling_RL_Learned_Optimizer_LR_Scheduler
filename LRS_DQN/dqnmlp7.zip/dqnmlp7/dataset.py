# dataset.py
import torch
from torch.utils.data import Dataset
import torchvision
from torchvision import transforms
import numpy as np
from sklearn.random_projection import GaussianRandomProjection

def fit_projector(data, n_components=48, random_state=42):
    projector = GaussianRandomProjection(n_components=n_components, random_state=random_state)
    projected = projector.fit_transform(data)
    mean = np.mean(projected, axis=0)
    std = np.std(projected, axis=0)
    return projector, mean, std

def apply_projection(data, projector, mean, std):
    projected = projector.transform(data)
    projected_norm = (projected - mean) / std
    return projected_norm

class ProjectedMNIST(Dataset):
    def __init__(self, train=True, projector=None, mean=None, std=None,
                 n_components=48, random_state=42):
        transform = transforms.Compose([transforms.ToTensor()])
        dataset = torchvision.datasets.MNIST(
            root="./data", train=train, download=True, transform=transform
        )

        # Flatten MNIST images (28x28 -> 784) and normalize to [0,1]
        images = dataset.data.view(len(dataset), -1).float() / 255.0
        labels = dataset.targets.numpy()

        images_np = images.numpy()

        if train:
            # For training: fit projector and compute mean, std
            projector, mean, std = fit_projector(images_np, n_components=n_components, random_state=random_state)
            projected_data = (projector.transform(images_np) - mean) / std
            self.projector = projector
            self.mean = mean
            self.std = std
        else:
            # For testing: use provided projector, mean, std
            if projector is None or mean is None or std is None:
                raise ValueError("For test dataset, projector, mean, and std are required.")
            projected_data = apply_projection(images_np, projector, mean, std)
            self.projector = projector
            self.mean = mean
            self.std = std

        self.data = torch.tensor(projected_data, dtype=torch.float32)
        self.labels = torch.tensor(labels, dtype=torch.long)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]