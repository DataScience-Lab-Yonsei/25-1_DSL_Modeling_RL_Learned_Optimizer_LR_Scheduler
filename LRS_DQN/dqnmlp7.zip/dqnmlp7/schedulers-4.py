# schedulers.py
import torch.optim

def apply_lr_action(optimizer, action, initial_lr):
    """
    Update the optimizer's learning rate based on the selected action.
    Modified actions:
      0: 학습률 3% 감소 (현재 lr * 0.97)
      1: 학습률 3% 증가 (현재 lr * 1.03)
      2: 학습률 10% 감소 (현재 lr * 0.90)
      3: 학습률 10% 증가 (현재 lr * 1.10)
      4: 초기값 재설정 (initial_lr 사용)
    """
    for param_group in optimizer.param_groups:
        current_lr = param_group['lr']
        if action == 0:
            new_lr = current_lr * 0.97  # 3% 감소
        elif action == 1:
            new_lr = current_lr * 1.03  # 3% 증가
        elif action == 2:
            new_lr = current_lr * 0.90  # 10% 감소
        elif action == 3:
            new_lr = current_lr * 1.10  # 10% 증가
        elif action == 4:
            new_lr = initial_lr         # 초기값 재설정
        else:
            raise ValueError("Invalid action selected for learning rate update.")
        param_group['lr'] = new_lr
    return optimizer