# train_utils.py
import torch
import torch.nn as nn
import math

def train_one_episode(model, optimizer, train_loader, device, scaler, total_epochs=10):
    """
    기존 함수(사용 안 함). 기존 코드 유지.
    """
    criterion = nn.CrossEntropyLoss()
    model.train()
    total_batches = len(train_loader)
    epoch_loss_list = []

    for epoch in range(total_epochs):
        running_loss = 0.0
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()

            with torch.amp.autocast(device_type="cuda" if torch.cuda.is_available() else "cpu"):
                output = model(data)
                loss = criterion(output, target)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()

        avg_epoch_loss = running_loss / total_batches
        epoch_loss_list.append(avg_epoch_loss)

    return epoch_loss_list

def train_one_epoch(model, optimizer, train_loader, device, scaler):
    """
    새로 추가된 함수: "단일 epoch"만 학습.
    반환값: 이 epoch의 평균 train loss
    """
    criterion = nn.CrossEntropyLoss()
    model.train()
    total_batches = len(train_loader)
    running_loss = 0.0

    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()

        with torch.amp.autocast(device_type="cuda" if torch.cuda.is_available() else "cpu"):
            output = model(data)
            loss = criterion(output, target)

        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        running_loss += loss.item()

    avg_epoch_loss = running_loss / total_batches
    return avg_epoch_loss

def evaluate(model, test_loader, device):
    """
    Evaluate the model on the test dataset and return average loss and accuracy.
    """
    model.eval()
    criterion = nn.CrossEntropyLoss()
    total_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            loss = criterion(output, target)
            total_loss += loss.item() * data.size(0)
            preds = output.argmax(dim=1)
            correct += (preds == target).sum().item()
            total += data.size(0)

    avg_loss = total_loss / total
    accuracy = correct / total
    return avg_loss, accuracy